# ioBroker-Veröffentlichungsassistent

Lokale TypeScript-CLI für Windows und Linux. Benötigt Node.js 24 oder neuer,
npm (für `npm trust` eine Version mit diesem Unterbefehl), Git und die
angemeldete GitHub CLI. Für npm-Änderungen meldest du dich über `npm login` an.
npm führt seine 2FA-Abfrage im Browser durch. Das Programm speichert keine Zugangsdaten.

Im Ordner des Assistenten ausführen:

```powershell
npm start -- status ../ioBroker.vis-2-widgets-ugso-spezial
npm start -- menu ../ioBroker.vis-2-widgets-ugso-spezial
```

| Befehl | Aktion |
| --- | --- |
| `status <Ordner>` | Zeigt lokale und veröffentlichte Version, npm-Mitinhaber, Herkunftsnachweis und passende Katalog-PRs. |
| `menu [Ordner]` | Startet den interaktiven Assistenten. Vor Aktionen mit Schreibzugriff fragt das Menü nach Bestätigung. |
| `verify <Ordner> [Workflowdatei]` | Prüft die lokale Version bei npm und zeigt den Herkunftsnachweis sowie den Status des zugehörigen GitHub-Workflows. |
| `owner-add <Ordner>` | Trägt bluefox bei npm ein, falls der Eintrag fehlt. |
| `trust-list <Ordner>` | Zeigt die bei npm eingerichteten Trusted Publisher. |
| `trust-add <Ordner> [Workflowdatei]` | Richtet den vorhandenen GitHub-Workflow als Trusted Publisher ein. |
| `release <Ordner> [Workflowdatei]` | Prüft Version, Git-Stand und Workflow, führt Build (falls vorhanden) und Tests aus und pusht den neuen Tag. |
| `recheck <Ordner> <PR-Nummer>` | Kommentiert `RE-CHECK!` in einem passenden offenen ioBroker-Katalog-PR. |

Release setzt den bereits eingerichteten Workflow mit Tag-Auslöser, OIDC und
der GitHub-Variable `NPM_TRUSTED_PUBLISHING=true` voraus, wie im UGSo-Spezial-Repository.
Standarddatei ist `test-and-release.yml`. Bereite die neue Version in den
Paketdateien vor, committe sie und pushe den Branch. Nach dem Release-Befehl
zeigt `verify` den Stand der Veröffentlichung und den Herkunftsnachweis für diese Version.
Die erstmalige npm-Veröffentlichung und das Anlegen eines neuen Katalog-PRs
erfolgen separat. Für die Statusabfrage werden die aktuellen Daten direkt abgerufen.
