# Sensor und Licht

Sensorwert als Zahl lesen, eine Grenze prüfen und Licht mit fester Helligkeit einschalten. Entitäten vor Verwendung ersetzen.

Version: 1.0.0
Autor: rockbaer2007
Lizenz: Apache-2.0

In UGSo Blocks for HA ab 0.1.18: Block-/Template-Editor > ZIP einlesen > Prüfen > Übernehmen.
Jinja wird erst in Home Assistant ausgewertet.
