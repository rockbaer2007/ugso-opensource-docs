import { spawnSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { createInterface } from 'node:readline/promises';

const registry = 'https://registry.npmjs.org';
const catalogue = 'ioBroker/ioBroker.repositories';

function run(tool: string, args: string[], cwd: string, interactive = false): string {
  let executable = tool;
  let parameters = args;
  if (tool === 'npm' && process.platform === 'win32') {
    const npmCli = join(dirname(process.execPath), 'node_modules', 'npm', 'bin', 'npm-cli.js');
    if (!existsSync(npmCli)) throw new Error('npm muss neben der Node.js-Installation verfügbar sein.');
    executable = process.execPath;
    parameters = [npmCli, ...args];
  }
  const result = spawnSync(executable, parameters, {
    cwd,
    encoding: 'utf8',
    stdio: interactive ? 'inherit' : ['ignore', 'pipe', 'pipe'],
    timeout: interactive ? undefined : 30_000,
  });
  if (result.error) throw new Error(tool + ': ' + result.error.message);
  if (result.status !== 0) {
    throw new Error(result.stderr?.trim() || tool + ' fehlgeschlagen (' + result.status + ').');
  }
  return result.stdout?.trim() ?? '';
}

function readJson(path: string) {
  return JSON.parse(readFileSync(path, 'utf8'));
}

function githubRepo(remote: string): string {
  const match = remote.match(/^(?:https:\/\/github\.com\/|git@github\.com:|ssh:\/\/git@github\.com\/)([\w.-]+\/[\w.-]+?)(?:\.git)?\/?$/i);
  if (!match) throw new Error('Erwartet eine GitHub-Adresse für origin.');
  return match[1];
}

async function registryPackage(name: string, suffix = '') {
  const response = await fetch(registry + '/' + encodeURIComponent(name) + suffix, {
    signal: AbortSignal.timeout(15_000),
  });
  if (response.status === 404) return null;
  if (!response.ok) throw new Error('npm-Registry antwortet mit HTTP ' + response.status);
  return response.json();
}

function printHelp() {
  console.log([
    'ioBroker-Veröffentlichungsassistent',
    'npm start -- menu [Adapterordner]',
    'npm start -- status <Adapterordner>',
    'npm start -- verify <Adapterordner> [Workflowdatei]',
    'npm start -- owner-add <Adapterordner>',
    'npm start -- trust-list <Adapterordner>',
    'npm start -- trust-add <Adapterordner> [Workflowdatei]',
    'npm start -- release <Adapterordner> [Workflowdatei]',
    'npm start -- recheck <Adapterordner> <Katalog-PR-Nummer>',
  ].join('\n'));
}

async function menu(defaultFolder?: string) {
  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    throw new Error('Das Menü benötigt ein interaktives Terminal. Einzelbefehle stehen unter help.');
  }
  let folder = defaultFolder;
  while (true) {
    const prompt = createInterface({ input: process.stdin, output: process.stdout });
    const cancellation = new AbortController();
    prompt.once('close', () => cancellation.abort());
    prompt.once('SIGINT', () => prompt.close());
    const ask = (label: string) => prompt.question(label, { signal: cancellation.signal });
    let selected: string;
    let argument: string | undefined;
    try {
      folder ||= (await ask('Adapterordner: ')).trim().replace(/^"([^"]+)"$/, '$1');
      if (!folder) return;
      console.log('\nAdapter: ' + resolve(folder));
      console.log('1 Status   2 Release prüfen   3 bluefox eintragen   4 Trusted Publisher anzeigen');
      console.log('5 Trusted Publisher einrichten   6 Release starten   7 Katalogprüfung starten');
      console.log('8 Adapter wechseln   0 Beenden');
      selected = (await ask('Auswahl: ')).trim();
      if (['2', '5', '6'].includes(selected)) {
        argument = (await ask('Workflowdatei [test-and-release.yml]: ')).trim() || undefined;
      }
      if (selected === '7') argument = (await ask('Katalog-PR-Nummer: ')).trim();
      if (['3', '5', '6', '7'].includes(selected) &&
          (await ask('Aktion ausführen? [j/N] ')).trim().toLowerCase() !== 'j') continue;
    } catch (error) {
      if (cancellation.signal.aborted) return;
      throw error;
    } finally {
      prompt.close();
    }
    if (selected === '0') return;
    if (selected === '8') {
      folder = undefined;
      continue;
    }
    const commands: Record<string, string> = {
      '1': 'status', '2': 'verify', '3': 'owner-add', '4': 'trust-list',
      '5': 'trust-add', '6': 'release', '7': 'recheck',
    };
    const command = commands[selected];
    if (!command) {
      console.error('Bitte eine Zahl von 0 bis 8 wählen.');
      continue;
    }
    try {
      await main(command, folder, argument);
    } catch (error) {
      console.error((error as Error).message);
    }
  }
}

async function main(command = 'help', folder?: string, argument?: string, extra?: string) {
  if (['help', '--help', '-h'].includes(command)) {
    printHelp();
    return;
  }
  if (command === 'menu' && !argument && !extra) return menu(folder);
  if (extra || !['status', 'verify', 'owner-add', 'trust-list', 'trust-add', 'release', 'recheck'].includes(command)) {
    throw new Error('Unbekannter Befehl oder zu viele Argumente. Hilfe: npm start -- help');
  }
  if (argument && ['status', 'owner-add', 'trust-list'].includes(command)) {
    throw new Error('Dieser Befehl erwartet nur den Adapterordner.');
  }
  const cwd = resolve(folder ?? '.');
  const pkg = readJson(join(cwd, 'package.json'));
  const io = readJson(join(cwd, 'io-package.json'));
  const name = pkg.name;
  const version = pkg.version;
  if (typeof name !== 'string' || !/^iobroker\.[a-z0-9][a-z0-9.-]*$/.test(name)) {
    throw new Error('package.json enthält keinen gültigen ioBroker-Paketnamen.');
  }
  if (io.common?.name !== name.slice('iobroker.'.length) ||
      typeof version !== 'string' || !/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(version) ||
      io.common?.version !== version) {
    throw new Error('Paketname oder stabile Version stimmen zwischen package.json und io-package.json nicht überein.');
  }
  const git = (...args: string[]) => run('git', args, cwd);
  const gh = (...args: string[]) => run('gh', args, cwd);
  const npm = (...args: string[]) => run('npm', [...args, '--registry=' + registry], cwd, true);
  const repo = githubRepo(git('remote', 'get-url', 'origin'));
  const adapter = io.common.name;

  function workflowFile(): string {
    const workflow = argument ?? 'test-and-release.yml';
    if (!/^[\w.-]+\.ya?ml$/.test(workflow) || !existsSync(join(cwd, '.github', 'workflows', workflow))) {
      throw new Error('Workflowdatei fehlt unter .github/workflows.');
    }
    return workflow;
  }

  function cataloguePr(number: string) {
    const pr = JSON.parse(gh('pr', 'view', number, '--repo', catalogue, '--json', 'title,state,url,headRepositoryOwner'));
    const titleTokens = pr.title.toLowerCase().split(/[^a-z0-9.-]+/);
    if (!titleTokens.includes(adapter) || pr.headRepositoryOwner?.login?.toLowerCase() !== repo.split('/')[0].toLowerCase()) {
      throw new Error('Der Katalog-PR passt nicht zum Adapter und GitHub-Konto.');
    }
    return pr;
  }

  switch (command) {
    case 'verify': {
      const workflow = workflowFile();
      const pkgInfo = await registryPackage(name);
      const release = pkgInfo?.versions?.[version];
      const latest = pkgInfo?.['dist-tags']?.latest;
      const attestations = release?.dist?.attestations;
      console.log('Version: ' + name + '@' + version);
      console.log('npm: ' + (release ? 'veröffentlicht' : 'noch nicht veröffentlicht'));
      console.log('npm latest: ' + (latest ?? 'kein Release gefunden'));
      console.log('Herkunftsnachweis: ' + (attestations?.provenance ? attestations.url : 'fehlt'));
      const runs = JSON.parse(gh('run', 'list', '--repo', repo, '--workflow', workflow,
        '--branch', 'v' + version, '--limit', '1', '--json', 'status,conclusion,url'));
      const runInfo = runs[0];
      console.log('GitHub Actions: ' + (runInfo
        ? (runInfo.conclusion || runInfo.status) + ' ' + runInfo.url
        : 'kein Lauf zum Versions-Tag gefunden'));
      break;
    }
    case 'status': {
      const pkgInfo = await registryPackage(name);
      const latest = pkgInfo?.['dist-tags']?.latest;
      const provenance = pkgInfo?.versions?.[latest]?.dist?.attestations?.provenance;
      const hasOwner = pkgInfo?.maintainers?.some((owner: { name: string }) => owner.name === 'bluefox');
      console.log('Projekt: ' + name + '@' + version + ' (' + repo + ')');
      console.log('npm latest: ' + (latest ?? 'kein Release gefunden'));
      console.log('Herkunftsnachweis für latest: ' + (provenance ? 'vorhanden' : 'fehlt'));
      console.log('bluefox: ' + (hasOwner ? 'eingetragen' : 'fehlt'));
      try {
        const prs = JSON.parse(gh('pr', 'list', '--repo', catalogue, '--state', 'all',
          '--search', 'in:title "' + adapter + '" author:' + repo.split('/')[0],
          '--json', 'number,title,state,url,headRepositoryOwner', '--limit', '20'));
        const matching = prs.filter((pr: { title: string; headRepositoryOwner?: { login: string } }) =>
          pr.title.toLowerCase().split(/[^a-z0-9.-]+/).includes(adapter) &&
          pr.headRepositoryOwner?.login?.toLowerCase() === repo.split('/')[0].toLowerCase());
        console.log('Katalog-PR: ' + (matching.length
          ? matching.map((pr: { number: number; state: string; url: string }) => '#' + pr.number + ' ' + pr.state + ' ' + pr.url).join('\n')
          : 'kein passender PR gefunden'));
      } catch (error) {
        console.error('Katalogstatus konnte nicht geprüft werden: ' + (error as Error).message);
        process.exitCode = 1;
      }
      break;
    }
    case 'owner-add':
      if ((await registryPackage(name))?.maintainers?.some((owner: { name: string }) => owner.name === 'bluefox')) {
        console.log('bluefox ist bereits eingetragen.');
      } else {
        npm('owner', 'add', 'bluefox', name);
      }
      break;
    case 'trust-list':
      npm('trust', 'list', name);
      break;
    case 'trust-add':
      npm('trust', 'github', name, '--repo', repo, '--file', workflowFile(), '--allow-publish');
      break;
    case 'release': {
      const workflow = workflowFile();
      const tag = 'v' + version;
      if (await registryPackage(name, '/' + version)) throw new Error('Diese Version ist bereits auf npm veröffentlicht.');
      if (git('status', '--porcelain')) throw new Error('Arbeitsbaum ist nicht sauber. Änderungen zuerst committen.');
      const branch = git('symbolic-ref', '--short', 'HEAD');
      const head = git('rev-parse', 'HEAD');
      const remote = git('ls-remote', '--heads', 'origin', 'refs/heads/' + branch);
      if (remote.split(/\s+/)[0] !== head) throw new Error('Der aktuelle Commit muss zuerst auf origin liegen.');
      if (git('tag', '--list', tag) || git('ls-remote', '--tags', 'origin', 'refs/tags/' + tag)) {
        throw new Error('Der Release-Tag existiert bereits.');
      }
      if (gh('variable', 'get', 'NPM_TRUSTED_PUBLISHING', '--repo', repo) !== 'true') {
        throw new Error('GitHub-Variable NPM_TRUSTED_PUBLISHING muss auf true stehen.');
      }
      const state = gh('api', 'repos/' + repo + '/actions/workflows/' + workflow, '--jq', '.state');
      if (state !== 'active') throw new Error('Der Release-Workflow ist auf GitHub nicht aktiv.');
      if (typeof pkg.scripts?.build === 'string') npm('run', 'build');
      npm('test');
      if (git('status', '--porcelain') || git('rev-parse', 'HEAD') !== head) {
        throw new Error('Der Arbeitsbaum oder Commit hat sich beim Test geändert.');
      }
      run('git', ['push', 'origin', head + ':refs/tags/' + tag], cwd, true);
      console.log('Tag veröffentlicht. Workflow: https://github.com/' + repo + '/actions/workflows/' + workflow);
      console.log('Nach dem Workflow mit status prüfen, ob npm die Version mit Herkunftsnachweis führt.');
      break;
    }
    case 'recheck': {
      if (!argument || !/^[1-9]\d*$/.test(argument)) throw new Error('Gib die Nummer des Katalog-PRs an.');
      const pr = cataloguePr(argument);
      if (pr.state !== 'OPEN') throw new Error('Der Katalog-PR ist geschlossen.');
      run('gh', ['pr', 'comment', argument, '--repo', catalogue, '--body', 'RE-CHECK!'], cwd, true);
      break;
    }
  }
}

const [command, folder, argument, extra] = process.argv.slice(2);
main(command, folder, argument, extra).catch((error: Error) => {
  console.error(error.message);
  process.exitCode = 1;
});
